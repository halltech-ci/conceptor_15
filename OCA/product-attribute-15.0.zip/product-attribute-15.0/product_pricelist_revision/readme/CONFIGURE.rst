To configure this module, you need to:

#. Go to *Sales > Configuration > Settings* and check
   "Pricelists" option and "Advanced price rules" after that.
