This module adds a 'Pricelist items' tree view that allows to select several
elements to version them and also to see the percentage 'fixed price'
variation between a version and the previous one.
