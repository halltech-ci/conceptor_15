To use this module, you need to:

#. Go to *Sales > Products > Pricelists* and create a new Price List.
#. Add a Pricelist Items to that Price List. Set 'Fix Price' value on the field
   'Compute Price' and set a fixed price.
#. Go to the new menu *Sales > Products > Pricelist Items*, select the
   previously created item and click on *Action > Duplicate Item*.
#. In the wizard set 'Date Start', set 'Date End' and set 'Variation %' to
   a value different from 100.
#. Click on 'Apply' and you will see a new Price List Item that is a copy of
   the previous item. In that new Item the value of the 'Fixed Price' field
   will be the previous price plus that price multiplied by the variation
   percentage and the value of the 'Variation %' will contain that value.
