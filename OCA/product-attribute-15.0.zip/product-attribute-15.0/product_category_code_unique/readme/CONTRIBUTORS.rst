* Denis Roussel <denis.roussel@acsone.eu>
* Rolando Duarte <rolando@vauxoo.com>
