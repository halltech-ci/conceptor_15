* Odoo S.A.
* Acysos SL <info@acysos.com>
* Ray Carnes <ray.carnes@bistasolutions.com>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Héctor Villarreal <hector.villarreal@forgeflow.com>
* Mantas Šniukas <mantas@vialaurea.lt>
