Although this module doesn't depend technically on **Sales Management**, you
must install it for configuring and seeing the effects of it.
