* First line that matches by minimum quantity criteria, independently from the
  supplier, will be the one that provides the price for the pricelist.
* There's no mechanism for selecting the supplier from possible sources like
  sales orders.
