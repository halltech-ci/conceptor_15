* `Tecnativa <https://www.tecnativa.com/>`_:

  * Vicent Cubells
  * Pedro M. Baeza
  * Carlos Roca

* Nikul Chaudhary <nikulchaudhary2112@gmail.com>

* `TAKOBI <https://takobi.online/>`_:

  * Lorenzo Battistini
