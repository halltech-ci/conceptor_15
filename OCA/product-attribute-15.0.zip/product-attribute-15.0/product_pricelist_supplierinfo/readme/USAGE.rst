For adding supplier info:

#. Go to *Sales > Products > Products*
#. Open or create a product.
#. Go to "Purchase" page.
#. On "Vendors" section, add the supplier and prices.
#. You can drag and drop for reordering these lines.

Check the remark in known issues about the supplier info line selection.

For checking pricelists in action, you can (with `sale` module installed):

#. Go to *Sales > Orders > Quotations*
#. Create or edit a quotation.
#. Add a line.
#. Select a product with the criteria to match the pricelist from supplier
   info.
#. See the proper price appears in the line.
