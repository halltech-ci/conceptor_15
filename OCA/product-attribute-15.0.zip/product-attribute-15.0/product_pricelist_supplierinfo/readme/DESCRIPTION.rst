This module allows you to create a sales pricelist based on product
supplierinfo prices. If you want, you can bypass minimum quantity in pricelist
item.

We can also define sale marging applied on purchase price directly on supplier info.
For this, you must add users to "Show sale margin on Product Supplierinfo" group.
