* The migration of this module from 12.0 to 14.0 was financially supported by
  Camptocamp.

Original implementation
-----------------------
* This module is inspired in previous module *product_images* from OpenLabs
  and Akretion.
