* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Rafael Blasco <rafabn@antiun.com>
* Jairo Llopis <yajo.sk8@gmail.com>
* Dave Lasley <dave@laslabs.com>
* Shepilov Vladislav <shepilov.v@protonmail.com>
* Marc Poch Mallandrich <mpoch@planetatic.com>
* Hai Lang <hailn@trobz.com>
* `Greenice <https://www.greenice.com>`_:

  * Fernando La Chica <fernandolachica@gmail.com>
