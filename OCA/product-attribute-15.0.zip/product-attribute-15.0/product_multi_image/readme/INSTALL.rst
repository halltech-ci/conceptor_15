To install this module, you need to:

* Install ``base_multi_image`` from
  `OCA/server-tools <https://github.com/OCA/server-tools>`_.
