This module implements the possibility to have multiple images for a product
template, a.k.a. an image gallery.
