# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl-3).

from . import image
from . import product_template
from . import product_product
