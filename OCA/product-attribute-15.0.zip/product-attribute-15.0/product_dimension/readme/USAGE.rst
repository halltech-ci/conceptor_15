To use this module :

#. Go to Product View > Inventory
#. Edit Dimensional UoM and the three dimensions

If the product has got more than one variant, the dimensions (and the volume) are visible only in the variants.
