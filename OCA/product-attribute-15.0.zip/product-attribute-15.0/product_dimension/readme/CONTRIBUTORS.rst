* Juan Jose Scarafia <jjs@ingadhoc.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Denis Leemann <denis.leemann@camptocamp.com>
* Kumar Aberer <kumar.aberer@braintec-group.com>
* `C2i Change 2 improve <http://www.c2i.es>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>
* Carlos Lopez <celm1990@gmail.com>
