This module extends the functionality of stock module to support net weight. (container excluded)
