In futur version (> 12.0), allow to compute Weight Price
(Net weight / Price).
For that purpose, refactor with ``product_logistics_uom``.

Ref : https://github.com/OCA/product-attribute/pull/894#issuecomment-895930887
