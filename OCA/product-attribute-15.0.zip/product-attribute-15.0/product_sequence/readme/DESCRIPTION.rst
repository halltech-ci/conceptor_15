This module allows to associate a sequence to the product reference.
The reference (default code) is unique (SQL constraint) and required.

You can optionally specify different sequences for different product
categories.
