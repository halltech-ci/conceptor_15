* Angel Moya <angel.moya@domatix.com>
* Graeme Gellatly <g@o4sb.com>
* Sodexis <dev@sodexis.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Sudhir Arya <sudhir@erpharbor.com>
* Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Watthanun Khorchai <watthanun_t@hotmail.com>
