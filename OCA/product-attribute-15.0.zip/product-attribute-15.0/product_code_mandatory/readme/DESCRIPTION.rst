This module sets the field internal reference (default_code) of the product
as required.
