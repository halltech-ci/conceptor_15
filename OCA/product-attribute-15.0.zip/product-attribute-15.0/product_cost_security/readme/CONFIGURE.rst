To use this module you need to:

#. Go to a *Setting > Users and Companies > Users*.
#. Select a user and add "Access to product costs" group.
