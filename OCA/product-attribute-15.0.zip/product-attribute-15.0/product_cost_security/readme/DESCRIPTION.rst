It adds two security groups, one for viewing the product cost price, and the other for
editing it.
