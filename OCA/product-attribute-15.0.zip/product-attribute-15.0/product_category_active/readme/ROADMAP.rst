* when you try to deactivate a category from the tree view
  by clicking on the boolean_toggle widget, if a validation
  error pop-up appears indicating that the element cannot be
  deactivated, then the element is NOT deactivated, although
  the corresponding line turns gray as if it had been disabled,
  until that tree view is refreshed.
