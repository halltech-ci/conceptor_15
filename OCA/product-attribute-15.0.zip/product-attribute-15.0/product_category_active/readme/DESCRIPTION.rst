This module allows you to archive product categories.
