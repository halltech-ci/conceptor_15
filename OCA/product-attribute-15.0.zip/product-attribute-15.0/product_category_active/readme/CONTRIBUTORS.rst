* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
  * Pedro M. Baeza
  * Carlos Roca

* Denis Roussel <denis.roussel@acsone.eu>
