To use this module, you need to:

#. Go to *Inventory > Configuration > Products > Product categories*.
#. Select a product category or create a new one.
#. Click on the smart button Archive (this action will set active
   field to False).

Note: If there are products in the category to be archived or any
of its children categories, an error will be raised and it won't be archived.

Note 2: Children category are not archived/unarchived
when the parent category does.
