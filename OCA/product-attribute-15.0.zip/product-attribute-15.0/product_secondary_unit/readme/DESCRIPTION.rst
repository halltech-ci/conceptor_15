This module extends the functionality of product module to allow define other units with their conversion factor.
