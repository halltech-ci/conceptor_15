This addon intends to manage product assortment. In Odoo you can only define
some filters defined by a domain but it can be sometimes really complicated.
With this addon you will be able to define a domain but also add some
products to include or to exclude through a allowed list and a restricted list.
This is done by overriding ir.capability but without influencing its standard
behaviour.
