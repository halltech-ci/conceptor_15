File data/product_state_data.xml will be moved to demo/product_state_demo.xml since version 15.0
