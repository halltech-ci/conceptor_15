To create a new state:

#. Go to *Sales > Configuration > Products > Product States*.
#. You can set its name and a description.

To add a product to a state:

#. Go to the product itself and edit.
#. You can select the desired status in the list of buttons above the form.
