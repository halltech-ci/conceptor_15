This module allows to set a different pricelist per each contact, so that such
pricelist is used in the sales flow.
