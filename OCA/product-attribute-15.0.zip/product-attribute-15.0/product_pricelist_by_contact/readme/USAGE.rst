#. Go to *Contacts* (you need to install module `contacts` for having this menu entry).
#. Select one contact that is not the parent one.
#. On the tab "Sales & Purchases", you will be able to select a different pricelist
   from its parent contact.
#. If you change the pricelist in the parent contact, the pricelist of the children
   contacts will be overwritten with this one, no matter the previous value.
