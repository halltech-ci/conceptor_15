* Not requiring to override any sales behavior is possible due to the way Odoo
  retrieves the pricelist directly associated to the contact, but no code is put
  here for assuring that such behavior is preserved across time.
