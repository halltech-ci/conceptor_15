* Ruchir Shukla <ruchir@bizzappdev.com>
* Dipen Shah <dipen.shah@bizzappdev.com>
* Tony Galmiche <tony.galmiche@infosaone.com>

* Tecnativa (https://www.tecnativa.com)
  * Carlos Dauden
  * Vicent Cubells
  * João Marques
