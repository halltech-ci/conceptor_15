This module allows create revisions of supplier info prices.
