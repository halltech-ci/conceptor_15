Configuration is not required.
