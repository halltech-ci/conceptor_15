- Got to: Sales -> Configuration -> Product Variant Values to manage extra price lines.
- You can edit *Extra Price* right in the list view.

To update values through spreadsheet, it is recommended to:
 - export records' external ID and relevant fields necessary to work on the spreadsheet (product template, attribute, attribute value, value price extra).
 - re-import records using only columns External ID and Value price extra.

To acces the attribute value view, simply go to Sales/Inventory > Configuration > Attribute Values.
