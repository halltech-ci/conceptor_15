This module adds:

- A menu item in Sales > Configuration called *Attribute Values Extra Prices*
  where user can see/edit all extra prices set for each attribute value in each
  product template. It also allows extra prices to be imported via standard
  csv/xlsx import.

- A menu item in Sales and Inventory Applications called *Attribute Values*,
  located under the *Attributes*' one. The new menu item contains all the
  Attribute Values on a tree view, having the attribute associated with a link
  and the value.
