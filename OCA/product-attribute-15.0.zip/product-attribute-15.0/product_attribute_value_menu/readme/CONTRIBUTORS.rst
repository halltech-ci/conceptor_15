* `Ooops404 <https://www.ooops404.com>`_:

  * Ilyas <irazor147@gmail.com>

* `ForgeFlow <http://www.forgeflow.com>`_:

  * Guillem Casassas <guillem.casassas@forgeflow.com>
