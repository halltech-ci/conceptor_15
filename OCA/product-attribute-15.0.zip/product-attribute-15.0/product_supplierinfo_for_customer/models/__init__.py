from . import product_pricelist
from . import product_customerinfo
from . import product_supplierinfo
from . import product_product
from . import product_template
from . import res_partner
