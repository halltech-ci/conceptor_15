Manage how to display the attributes on the product variant name.

* Choose if you want to display the name of the attribute before its value.
* Set a short name to be displayed as the attribute's name.
* Set the order of the attributes for each product.
