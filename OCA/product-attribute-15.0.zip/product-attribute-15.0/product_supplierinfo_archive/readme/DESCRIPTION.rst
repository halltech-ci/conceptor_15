This module adds the field active to product.supplierinfo so it can be archived.
