Simply use the archive action on any product supplier info.

Existing variants are unaffected, only new ones.
