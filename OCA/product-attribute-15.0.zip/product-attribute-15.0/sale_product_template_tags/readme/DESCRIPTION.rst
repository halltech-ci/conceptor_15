Shows the Product Tags menu in Sales app
