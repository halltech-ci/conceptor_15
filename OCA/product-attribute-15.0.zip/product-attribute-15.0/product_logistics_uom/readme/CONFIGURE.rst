To change the default UoM

#. Go "General Settings", then in "Products"
#. you have to select a default unit of measure for weights and volumes.

To change on a specific product

#. Go the product form you can change the UoM directly.
