This addon allows to add tags on products.
