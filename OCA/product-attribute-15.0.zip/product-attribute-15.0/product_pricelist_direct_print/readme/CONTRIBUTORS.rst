* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * David Vidal
  * Sergio Teruel
  * João Marques
  * Carlos Roca

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
