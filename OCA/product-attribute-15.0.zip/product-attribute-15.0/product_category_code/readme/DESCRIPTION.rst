This module adds a field 'code' on product category level.
