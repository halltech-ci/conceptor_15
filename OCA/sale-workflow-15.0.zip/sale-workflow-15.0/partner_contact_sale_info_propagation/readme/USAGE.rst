To use this module, if *Contacts* module is installed:

#. Go to *Contacts -> Contacts* and create a new contact with Company radio
   button checked and a Salesperson selected in *Sales & Purchases* tab
#. Edit this record and add a new contact child in *Contacts & Addresses* tab
#. Go to *Contacts -> Contacts* and open the company created
   (contact type company) and its contact child and you will see they have the
   same *Salesperson*
