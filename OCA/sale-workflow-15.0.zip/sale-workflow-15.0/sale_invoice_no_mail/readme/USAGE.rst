To use this module, you just need to install it.
