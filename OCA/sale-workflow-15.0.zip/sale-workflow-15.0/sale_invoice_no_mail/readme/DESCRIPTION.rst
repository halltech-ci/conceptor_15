Avoid sending emails when a new invoice is created from a sale order
