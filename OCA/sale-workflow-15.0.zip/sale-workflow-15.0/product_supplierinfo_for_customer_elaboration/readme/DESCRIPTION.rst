This modules allows to use supplier info structure, available in
*Inventory* tab of the product form, also for defining customer information,
allowing to define default elaboration per customer and product.
