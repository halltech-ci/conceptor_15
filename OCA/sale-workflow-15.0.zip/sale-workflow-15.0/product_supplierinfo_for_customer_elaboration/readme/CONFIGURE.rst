To see this module working you need to define some elaborations as the module
`sale_elaboration <https://github.com/OCA/sale-workflow/tree/13.0/sale_elaboration>`_
explains.
