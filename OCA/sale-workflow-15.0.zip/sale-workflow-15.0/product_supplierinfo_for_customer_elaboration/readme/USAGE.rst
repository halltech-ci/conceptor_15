To use this module, you need to:

#. Go to *Sales > Products > Products*
#. Create or select one of existing
#. Go to window *Sales* and create a new entry for some customer
#. Select one elaboration and one elaboration note

After this create a new quotation and select the partner with that was configured.
You will see that the elaboration and the elaboration note is completed.
