This module adds the last sale info of the product.
*  Last Sale Price
*  Last Sale Date
*  Last Customer
