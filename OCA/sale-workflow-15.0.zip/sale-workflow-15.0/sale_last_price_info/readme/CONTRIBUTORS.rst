* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
* Ruchir Shukla <ruchir@bizzappdev.com>
