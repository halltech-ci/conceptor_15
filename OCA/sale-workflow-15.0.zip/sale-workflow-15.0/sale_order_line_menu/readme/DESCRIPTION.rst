Adds a menu item to list all Sales order lines.
