#. Go to *Sale > Quotations*.
#. Create a sales order.
#. Add a new line.
#. Select an elaboration in the line.
#. Confirm the sales order.
#. Go to the picking created by this sales order and validate it.
#. Go back to the sales order. A new line is created with the product linked to
   the elaboration.
