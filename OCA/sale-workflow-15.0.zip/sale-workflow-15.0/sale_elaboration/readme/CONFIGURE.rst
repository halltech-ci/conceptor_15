To configure this module you need to:

#. Go to *Sale > Configuration > Products > Sale Elaboration*.
#. Create a new record.
#. Set a product linked to the elaboration.
