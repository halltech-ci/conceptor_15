You can group by *Commercial Entity*:

* in *Sales > Orders > Quotations*,
* in *Sales > Orders > Orders*,
* in *Sales > Reporting > Sales* (it is a native feature in this menu)
