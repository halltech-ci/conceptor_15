To configure this module, you need to:

#. Go to 'Sales > Configuration > Sales > Invoicing block reasons'.
#. Create the different reasons that can lead to block the invoices of a
   sales order.
