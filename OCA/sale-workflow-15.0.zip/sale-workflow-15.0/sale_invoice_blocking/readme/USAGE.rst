To use this module, you need to:

#. Create a new sale order and provide a 'Blocking for invoicing'.
#. Button "Create Invoice" is invisible if an invoicing blocking reason is set on the sale order
