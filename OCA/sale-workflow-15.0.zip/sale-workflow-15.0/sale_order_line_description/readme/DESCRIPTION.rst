This module sets to use only product's sale description field on the sale order
lines, instead of "Ref+Name+Sale Description".
