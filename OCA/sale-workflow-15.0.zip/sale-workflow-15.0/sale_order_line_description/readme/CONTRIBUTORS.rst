* Alex Comba <alex.comba@agilebg.com>
* Daniel Campos <danielcampos@avanzosc.es>
* Simone Rubino <simone.rubino@agilebg.com>
* `Tecnativa <https://www.tecnativa.com>`_ :

  * Vicent Cubells

 * Rataapong Chokmasermkul <rattapongc@ecosoft.co.th>
