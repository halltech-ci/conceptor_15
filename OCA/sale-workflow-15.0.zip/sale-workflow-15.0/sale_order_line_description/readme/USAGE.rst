#. Go to **Sales > Settings > Quotations & Orders** and check "Product Sale
   description* to use only product sale description on the sales order lines.
#. Go to **Setting > Users & Companies > Users** and check you have checked
   the "Use only product purchase description on order lines" access right for
   your user.
#. Add or modify a sale description to any of your products.
#. Create a sale order and add a sale order line with this product and check
   out that now sale order line description only contains the sale description
   you entered.
