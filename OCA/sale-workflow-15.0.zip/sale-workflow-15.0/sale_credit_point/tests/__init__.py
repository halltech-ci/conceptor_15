from . import test_credit
from . import test_wizard
from . import test_sale_order
from . import test_credit_history
