15.0.1.1.0 (2022-05-10)
~~~~~~~~~~~~~~~~~~~~~~~

* remove dependency on stock



12.0.1.0.0 (2019-03-08)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of the history
