The automatic workflow associated to a payment mode can be chosen in
the configuration of the payment modes in the Invoicing configuration menu.
