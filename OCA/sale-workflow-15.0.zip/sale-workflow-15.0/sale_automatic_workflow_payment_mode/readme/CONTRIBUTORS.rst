* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Sodexis <dev@sodexis.com>

* `Greenice <https://www.greenice.com>`_:

  * Fernando La Chica <fernandolachica@gmail.com>
