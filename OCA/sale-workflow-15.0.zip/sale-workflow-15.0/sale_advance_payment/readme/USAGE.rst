
To use this module, you need to:

* Go to a sale order.
* Click on "Pay Sale Advance".
* Select the Journal and specify the amount of the advanced payment.
* "Make Advance Payment".

When generating the invoice, the system displays the advanced payments, select those you want to add to the invoice.
