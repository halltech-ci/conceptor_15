Split several computed values in separate fields (mls, advance_amount, amount_residual).
This allows a better comprehension of logic, and a better inheritance possibility.
