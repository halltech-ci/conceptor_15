This module assigns automatically delivery carrier on sale order confirmation.
