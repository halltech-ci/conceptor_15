This modules helps to get Invoicing Policy on Sale Order Level without
breaking behaviour (as it is defined from >= v10 on product level).
