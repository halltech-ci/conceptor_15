* Create Sale Order
* Select Invoicing Policy on Sale Order or let it void
* Either the policy selected on Sale Order would be used, either if not
  filled in, the policy would be chosen from product configuration
