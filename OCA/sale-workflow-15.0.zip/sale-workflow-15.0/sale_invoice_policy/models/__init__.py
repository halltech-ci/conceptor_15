from . import product_template
from . import res_config_settings
from . import sale_order
from . import sale_order_line
