This module extends the functionality of sale module to allow you to
see a sales analysis for a customer from his/her form view, grouped
by products in rows and confirmation dates in columns.
