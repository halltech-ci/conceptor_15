To use this module, you need to:

#. Go to a customer form view
#. Click on *Sales Analysis* smart-button and you will see
   a sales analysis for this customer grouped by products in
   rows and confirmation dates in columns.

This button will only be visible to users who belong to one of
the sales access groups
