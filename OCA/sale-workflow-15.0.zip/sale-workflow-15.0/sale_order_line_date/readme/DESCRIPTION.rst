This module adds a commitment date to each sale order line and propagate it to
stock moves and pickings.
The commitment date of the whole sale order is computed based on each sale order
line date and the sale order shipping policy. It can't be modified.
