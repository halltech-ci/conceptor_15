* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Esther Martín <esthermartin@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Jordi Ballester <jordi.ballester@forgeflow.com>
* Aaron Henriquez <ahenriquez@forgeflow.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Open-Net Sàrl <jae@open-net.ch>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Moaad Bourhim <moaad.bourhim@gmail.com>
* Bernat Puig <bernat.puig@forgeflow.com>
