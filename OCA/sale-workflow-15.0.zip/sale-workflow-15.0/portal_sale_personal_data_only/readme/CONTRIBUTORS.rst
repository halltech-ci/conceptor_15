* Harald Panten <harald.panten@sygel.es>

* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal
  * Víctor Martínez

* Moaad Bourhim <moaad.bourhim@gmail.com>
* Jairo Llopis (`Moduon <https://www.moduon.team/>`__)
