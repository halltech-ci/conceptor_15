By default, portal users are allowed to see all the sale orders in
which a member of their organization are followers. That could cause a leaking
of  documents between members and departments and of the organization that
should stay private.

This module restricts that behaviour so the portal users only see their own
documents.
