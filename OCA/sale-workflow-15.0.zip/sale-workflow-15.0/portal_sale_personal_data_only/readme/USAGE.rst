#. Create some portal users belonging to the same company.
#. Place some orders for several of these users.
#. Log in with each portal user credential.
#. Only the sale orders belonging to the logged in user's partner or
   his descendants should be accessible.
#. Invoices associated to a partner's sale order will be visible as well.
