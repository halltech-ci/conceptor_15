* Pierrick BRUN <pierrick.brun@akretion.com>
* Benoît Guillot <benoit.guillot@akretion.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Daniel Reis <dreis@opensourceintegrators.com>,
  `Open Source Integrators <https://opensourceintegrators.com>`_
* Carlos Lopez <celm1990@gmail.com>
