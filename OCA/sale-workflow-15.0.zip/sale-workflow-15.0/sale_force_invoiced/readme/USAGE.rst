#. Create a sales order and confirm it.
#. Deliver the products/services.
#. Create an invoice and reduce the invoiced quantity. The sales order
   invoicing status is 'To Invoice'.
#. Check the field 'Force Invoiced'. The sales order invoicing status will be
   'Invoiced'.
