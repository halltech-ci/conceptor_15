This module brings the possibility to indicate if a task is available to be
invoiced or not, within the task itself. Moreover, even if the task is not
finished yet, it can be set as invoiceable.

As an option, you can relate this control to a Project Stage
( ``project.task.type`` ). For example, if you want to assign 'Invoiceable' to
``Done`` stage always.
