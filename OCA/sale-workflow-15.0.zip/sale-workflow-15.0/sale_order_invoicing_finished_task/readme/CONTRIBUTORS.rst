* Denis Leemann <denis.leemann@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Carlos Dauden
  * Alexandre Díaz
  * João Marques
  * Ernesto Tejeda
  * César A. Sánchez
  * Luis D. Lafaurie

* nikulchaudhary2112@gmail.com
