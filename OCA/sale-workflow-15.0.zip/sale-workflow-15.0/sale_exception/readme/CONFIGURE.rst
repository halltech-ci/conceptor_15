If you are going to use Customer sale warning and Product warning,
for setting corresponding information, you need to:

#. Go to *Settings > User & Companies > Users*.
#. Edit your user.
#. Check "A warning can be set on a product or a customer (Sale)" group.
#. Install sale_management addon.
