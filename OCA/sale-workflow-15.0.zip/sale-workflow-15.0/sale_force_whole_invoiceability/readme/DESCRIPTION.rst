This module allows to the sale managers to force all the lines to invoice independently
of the invoice policy and the delivered quantities of the products.
