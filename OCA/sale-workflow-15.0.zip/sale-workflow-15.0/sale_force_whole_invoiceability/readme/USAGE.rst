To use this module, you need to:

#. Make a sale order with products with a `delivered quantities` invoice policy.
#. Confirm the order.
#. If you try to invoice the order, you can't as the quantities aren't delivered.
#. But if you are a `Sales Manager`, you have a new button *Force Invoice Policy*
#. Once clicked, you can invoice all the lines as if they were already delivered.
