To archive sale orders, you need to:

#. Open the tree view of sale orders.
#. Select a sale order (in status Locked or Cancelled) you want to archive.
#. Click on Action > Archive. Confirm.
#. The sale order is now archived.

To unarchive sale orders, you need to:

#. Open the tree view of sale orders.
#. In the filter box select the Archived filter. The list of archived sale orders will be displayed.
#. Select the sale order (in status Locked or Cancelled) you want to restore to Active.
#. Click on the Action > Unarchive.
#. The sale order is now active.
