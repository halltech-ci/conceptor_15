To use this module, you need to:

#. Go to Sales > Orders > Sales Orders Lines
#. You can filter, group and switch view type
#. Create new line related with existing order
#. If order field is empty, a new order will be created
