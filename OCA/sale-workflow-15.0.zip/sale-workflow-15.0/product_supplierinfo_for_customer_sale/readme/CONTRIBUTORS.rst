* Xavier Jimenez <xavier.jimenez@qubiq.es>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Moisés López <moylop260@vauxoo.com>
* Yennifer Santiago <yennifer@vauxoo.com>
* Julio Serna Hernández <julio@vauxoo.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Juany Davila <juany.davila@forgeflow.com>
