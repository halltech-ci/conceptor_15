The purpose of this module is to add two fields in the sale order model:

* invoiced_amount: total invoiced amount.
* uninvoiced_amount: total uninvoiced amount.
